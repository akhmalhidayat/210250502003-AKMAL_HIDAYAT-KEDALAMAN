/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROGRAM_IF_2_KONDISI;

import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class DUA_KONDISI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int kedalaman;
        System.out.print("Masukkan berapa meter kedalaman air laut : ");
        kedalaman = input.nextInt();

        if (kedalaman < 200) {
            System.out.println("Zona Lithorial");
        } else if (kedalaman >= 200 && kedalaman <= 1800) {
            System.out.println("Zona Neritik");
        } else {
            System.out.println("Zona Batial");
        }
    }
}
