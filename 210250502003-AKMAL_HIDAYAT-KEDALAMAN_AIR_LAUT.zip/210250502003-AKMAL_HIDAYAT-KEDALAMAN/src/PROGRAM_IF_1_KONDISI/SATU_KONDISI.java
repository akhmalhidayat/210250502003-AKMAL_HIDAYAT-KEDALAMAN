/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROGRAM_IF_1_KONDISI;

import java.util.Scanner;

/**
 *
 * @author LENOVO
 */
public class SATU_KONDISI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int kedalaman;
        System.out.print("Masukkan Berapa Meter Kedalaman Air Laut : ");
        kedalaman = input.nextInt();

        if (kedalaman >= 1800 && kedalaman <= 2000) {
            System.out.println("Zona Bathial");
        } else {
            System.out.println("Zona Abisyal");
        }
    }
}
